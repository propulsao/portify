export interface Hero {
  _id: string;
  title?: string;
  subtitle?: string;
  backgroundImage: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
}