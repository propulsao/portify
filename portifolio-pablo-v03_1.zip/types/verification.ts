export interface VerificationResult {
  email: string;
  status: string;
  error?: string;
}